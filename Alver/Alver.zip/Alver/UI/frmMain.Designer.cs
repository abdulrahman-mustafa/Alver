﻿namespace Alver.Forms
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.HeadersplitContainer = new System.Windows.Forms.SplitContainer();
            this.mainmenustrip = new System.Windows.Forms.MenuStrip();
            this.ملفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.أخذنسخةاحتياطيةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.استرجاعنسخةاحتياطيةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إعدادتالبرنامجToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.إغلاقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مساعدإعدادقاعدةالبياناتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addclientbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.clientsbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.clientoverviewbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.دفعاتالوكلاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إضافةدفعةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضالدفعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.withdrawbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.إضافةحركةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضالحركاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.قصوتحويلالرصيدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cutbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.transferbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضالعملياتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تصنيفاتالوكلاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مطابقاتالوكلاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الموادToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إضافةمادةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضالموادToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تصنيفاتالموادToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الواحداتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.كشفحسابمادةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تسعيرالموادToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.كمياتالموادToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.كشفحركةالمادةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.billsbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.POSbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.buybillbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.sellbillbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.billmanagementbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.الصناديقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.سحبوتغذيةالصناديقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إضافةحركةToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضالحركاتToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.كشفحسابتفصيليToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.floatingfundsbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.الصرافةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إضافةعملياتصرافةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.نشرةالأسعارToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المصاريفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addExpensebtn = new System.Windows.Forms.ToolStripMenuItem();
            this.viewExpensesbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.expensesCategoriesbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.المدفوعاتوالمقبوضاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الديونToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addLoanbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.viewLoansbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.depositesbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.addDepositebtn = new System.Windows.Forms.ToolStripMenuItem();
            this.viewDepositesbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.المستخدمونToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إدارةالمستخدمينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BodysplitContainer = new System.Windows.Forms.SplitContainer();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.clocklbl = new System.Windows.Forms.Label();
            this.phonelbl = new System.Windows.Forms.Label();
            this.addresslbl = new System.Windows.Forms.Label();
            this.companytitlelbl = new System.Windows.Forms.Label();
            this.mainstatusstrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.usernameLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.databasenamelbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.runtimeslbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.HeadersplitContainer)).BeginInit();
            this.HeadersplitContainer.Panel1.SuspendLayout();
            this.HeadersplitContainer.Panel2.SuspendLayout();
            this.HeadersplitContainer.SuspendLayout();
            this.mainmenustrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BodysplitContainer)).BeginInit();
            this.BodysplitContainer.Panel1.SuspendLayout();
            this.BodysplitContainer.Panel2.SuspendLayout();
            this.BodysplitContainer.SuspendLayout();
            this.mainstatusstrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // HeadersplitContainer
            // 
            this.HeadersplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.HeadersplitContainer.Location = new System.Drawing.Point(0, 0);
            this.HeadersplitContainer.Name = "HeadersplitContainer";
            this.HeadersplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // HeadersplitContainer.Panel1
            // 
            this.HeadersplitContainer.Panel1.Controls.Add(this.mainmenustrip);
            this.HeadersplitContainer.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // HeadersplitContainer.Panel2
            // 
            this.HeadersplitContainer.Panel2.Controls.Add(this.BodysplitContainer);
            this.HeadersplitContainer.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.HeadersplitContainer.Size = new System.Drawing.Size(882, 449);
            this.HeadersplitContainer.SplitterDistance = 29;
            this.HeadersplitContainer.SplitterWidth = 20;
            this.HeadersplitContainer.TabIndex = 0;
            // 
            // mainmenustrip
            // 
            this.mainmenustrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mainmenustrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ملفToolStripMenuItem,
            this.testToolStripMenuItem,
            this.الموادToolStripMenuItem,
            this.billsbtn,
            this.الصناديقToolStripMenuItem,
            this.الصرافةToolStripMenuItem,
            this.المصاريفToolStripMenuItem,
            this.المدفوعاتوالمقبوضاتToolStripMenuItem,
            this.المستخدمونToolStripMenuItem});
            this.mainmenustrip.Location = new System.Drawing.Point(0, 0);
            this.mainmenustrip.Name = "mainmenustrip";
            this.mainmenustrip.Size = new System.Drawing.Size(882, 28);
            this.mainmenustrip.TabIndex = 0;
            this.mainmenustrip.Text = "menuStrip1";
            // 
            // ملفToolStripMenuItem
            // 
            this.ملفToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.أخذنسخةاحتياطيةToolStripMenuItem,
            this.استرجاعنسخةاحتياطيةToolStripMenuItem,
            this.إعدادتالبرنامجToolStripMenuItem,
            this.logoutbtn,
            this.إغلاقToolStripMenuItem,
            this.مساعدإعدادقاعدةالبياناتToolStripMenuItem});
            this.ملفToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_file_25px;
            this.ملفToolStripMenuItem.Name = "ملفToolStripMenuItem";
            this.ملفToolStripMenuItem.Size = new System.Drawing.Size(62, 24);
            this.ملفToolStripMenuItem.Text = "ملف";
            // 
            // أخذنسخةاحتياطيةToolStripMenuItem
            // 
            this.أخذنسخةاحتياطيةToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_database_export_25px;
            this.أخذنسخةاحتياطيةToolStripMenuItem.Name = "أخذنسخةاحتياطيةToolStripMenuItem";
            this.أخذنسخةاحتياطيةToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.أخذنسخةاحتياطيةToolStripMenuItem.Text = "أخذ نسخة احتياطية";
            this.أخذنسخةاحتياطيةToolStripMenuItem.Click += new System.EventHandler(this.أخذنسخةاحتياطيةToolStripMenuItem_Click);
            // 
            // استرجاعنسخةاحتياطيةToolStripMenuItem
            // 
            this.استرجاعنسخةاحتياطيةToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_database_restore_25px;
            this.استرجاعنسخةاحتياطيةToolStripMenuItem.Name = "استرجاعنسخةاحتياطيةToolStripMenuItem";
            this.استرجاعنسخةاحتياطيةToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.استرجاعنسخةاحتياطيةToolStripMenuItem.Text = "استرجاع نسخة احتياطية";
            this.استرجاعنسخةاحتياطيةToolStripMenuItem.Click += new System.EventHandler(this.استرجاعنسخةاحتياطيةToolStripMenuItem_Click);
            // 
            // إعدادتالبرنامجToolStripMenuItem
            // 
            this.إعدادتالبرنامجToolStripMenuItem.Image = global::Alver.Properties.Resources.settings;
            this.إعدادتالبرنامجToolStripMenuItem.Name = "إعدادتالبرنامجToolStripMenuItem";
            this.إعدادتالبرنامجToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.إعدادتالبرنامجToolStripMenuItem.Text = "إعدادت البرنامج";
            this.إعدادتالبرنامجToolStripMenuItem.Click += new System.EventHandler(this.إعدادتالبرنامجToolStripMenuItem_Click);
            // 
            // logoutbtn
            // 
            this.logoutbtn.Image = global::Alver.Properties.Resources.icons8_exit_sign_25px;
            this.logoutbtn.Name = "logoutbtn";
            this.logoutbtn.Size = new System.Drawing.Size(209, 26);
            this.logoutbtn.Text = "تسجيل الخروج";
            this.logoutbtn.Click += new System.EventHandler(this.logoutbtn_Click_1);
            // 
            // إغلاقToolStripMenuItem
            // 
            this.إغلاقToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_shutdown_25px;
            this.إغلاقToolStripMenuItem.Name = "إغلاقToolStripMenuItem";
            this.إغلاقToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.إغلاقToolStripMenuItem.Text = "إغلاق";
            this.إغلاقToolStripMenuItem.Click += new System.EventHandler(this.إغلاقToolStripMenuItem_Click);
            // 
            // مساعدإعدادقاعدةالبياناتToolStripMenuItem
            // 
            this.مساعدإعدادقاعدةالبياناتToolStripMenuItem.Name = "مساعدإعدادقاعدةالبياناتToolStripMenuItem";
            this.مساعدإعدادقاعدةالبياناتToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.مساعدإعدادقاعدةالبياناتToolStripMenuItem.Text = "مساعد إعداد قاعدة البيانات";
            this.مساعدإعدادقاعدةالبياناتToolStripMenuItem.Click += new System.EventHandler(this.مساعدإعدادقاعدةالبياناتToolStripMenuItem_Click);
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addclientbtn,
            this.clientsbtn,
            this.clientoverviewbtn,
            this.toolStripSeparator2,
            this.دفعاتالوكلاءToolStripMenuItem,
            this.toolStripSeparator3,
            this.withdrawbtn,
            this.toolStripSeparator4,
            this.قصوتحويلالرصيدToolStripMenuItem,
            this.تصنيفاتالوكلاءToolStripMenuItem,
            this.مطابقاتالوكلاءToolStripMenuItem});
            this.testToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_management_25px;
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(70, 24);
            this.testToolStripMenuItem.Text = "الوكلاء";
            // 
            // addclientbtn
            // 
            this.addclientbtn.Image = global::Alver.Properties.Resources.adduser;
            this.addclientbtn.Name = "addclientbtn";
            this.addclientbtn.Size = new System.Drawing.Size(183, 26);
            this.addclientbtn.Text = "إضافة وكيل";
            this.addclientbtn.Click += new System.EventHandler(this.addclientbtn_Click);
            // 
            // clientsbtn
            // 
            this.clientsbtn.Image = global::Alver.Properties.Resources.icons8_user_account_skin_type_7_25px;
            this.clientsbtn.Name = "clientsbtn";
            this.clientsbtn.Size = new System.Drawing.Size(183, 26);
            this.clientsbtn.Text = "عرض الوكلاء";
            this.clientsbtn.Click += new System.EventHandler(this.clientsbtn_Click);
            // 
            // clientoverviewbtn
            // 
            this.clientoverviewbtn.Image = global::Alver.Properties.Resources.icons8_find_user_male_25px;
            this.clientoverviewbtn.Name = "clientoverviewbtn";
            this.clientoverviewbtn.Size = new System.Drawing.Size(183, 26);
            this.clientoverviewbtn.Text = "كشف حساب تفصيلي";
            this.clientoverviewbtn.Click += new System.EventHandler(this.clientoverviewbtn_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(180, 6);
            // 
            // دفعاتالوكلاءToolStripMenuItem
            // 
            this.دفعاتالوكلاءToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إضافةدفعةToolStripMenuItem,
            this.عرضالدفعاتToolStripMenuItem});
            this.دفعاتالوكلاءToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_debt_25px_1;
            this.دفعاتالوكلاءToolStripMenuItem.Name = "دفعاتالوكلاءToolStripMenuItem";
            this.دفعاتالوكلاءToolStripMenuItem.Size = new System.Drawing.Size(183, 26);
            this.دفعاتالوكلاءToolStripMenuItem.Text = "دفعات الوكلاء";
            // 
            // إضافةدفعةToolStripMenuItem
            // 
            this.إضافةدفعةToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_cash_in_hand_25px1;
            this.إضافةدفعةToolStripMenuItem.Name = "إضافةدفعةToolStripMenuItem";
            this.إضافةدفعةToolStripMenuItem.Size = new System.Drawing.Size(148, 26);
            this.إضافةدفعةToolStripMenuItem.Text = "إضافة دفعة";
            this.إضافةدفعةToolStripMenuItem.Click += new System.EventHandler(this.إضافةدفعةToolStripMenuItem_Click);
            // 
            // عرضالدفعاتToolStripMenuItem
            // 
            this.عرضالدفعاتToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_list_25px;
            this.عرضالدفعاتToolStripMenuItem.Name = "عرضالدفعاتToolStripMenuItem";
            this.عرضالدفعاتToolStripMenuItem.Size = new System.Drawing.Size(148, 26);
            this.عرضالدفعاتToolStripMenuItem.Text = "عرض الدفعات";
            this.عرضالدفعاتToolStripMenuItem.Click += new System.EventHandler(this.عرضالدفعاتToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(180, 6);
            // 
            // withdrawbtn
            // 
            this.withdrawbtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إضافةحركةToolStripMenuItem,
            this.عرضالحركاتToolStripMenuItem});
            this.withdrawbtn.Image = global::Alver.Properties.Resources.icons8_cash_in_hand_25px;
            this.withdrawbtn.Name = "withdrawbtn";
            this.withdrawbtn.Size = new System.Drawing.Size(183, 26);
            this.withdrawbtn.Text = "سحب وإيداع";
            // 
            // إضافةحركةToolStripMenuItem
            // 
            this.إضافةحركةToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_cash_in_hand_25px;
            this.إضافةحركةToolStripMenuItem.Name = "إضافةحركةToolStripMenuItem";
            this.إضافةحركةToolStripMenuItem.Size = new System.Drawing.Size(146, 26);
            this.إضافةحركةToolStripMenuItem.Text = "إضافة حركة";
            this.إضافةحركةToolStripMenuItem.Click += new System.EventHandler(this.إضافةحركةToolStripMenuItem_Click);
            // 
            // عرضالحركاتToolStripMenuItem
            // 
            this.عرضالحركاتToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_list_25px;
            this.عرضالحركاتToolStripMenuItem.Name = "عرضالحركاتToolStripMenuItem";
            this.عرضالحركاتToolStripMenuItem.Size = new System.Drawing.Size(146, 26);
            this.عرضالحركاتToolStripMenuItem.Text = "عرض الحركات";
            this.عرضالحركاتToolStripMenuItem.Click += new System.EventHandler(this.عرضالحركاتToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(180, 6);
            // 
            // قصوتحويلالرصيدToolStripMenuItem
            // 
            this.قصوتحويلالرصيدToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cutbtn,
            this.transferbtn,
            this.عرضالعملياتToolStripMenuItem});
            this.قصوتحويلالرصيدToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_tax_25px;
            this.قصوتحويلالرصيدToolStripMenuItem.Name = "قصوتحويلالرصيدToolStripMenuItem";
            this.قصوتحويلالرصيدToolStripMenuItem.Size = new System.Drawing.Size(183, 26);
            this.قصوتحويلالرصيدToolStripMenuItem.Text = "قص وتحويل الرصيد";
            // 
            // cutbtn
            // 
            this.cutbtn.Image = global::Alver.Properties.Resources.icons8_tax_25px;
            this.cutbtn.Name = "cutbtn";
            this.cutbtn.Size = new System.Drawing.Size(151, 26);
            this.cutbtn.Text = "قص رصيد";
            this.cutbtn.Click += new System.EventHandler(this.cutbtn_Click);
            // 
            // transferbtn
            // 
            this.transferbtn.Image = global::Alver.Properties.Resources.icons8_exchange_skin_type_7_25px;
            this.transferbtn.Name = "transferbtn";
            this.transferbtn.Size = new System.Drawing.Size(151, 26);
            this.transferbtn.Text = "تحويل رصيد";
            this.transferbtn.Click += new System.EventHandler(this.transferbtn_Click);
            // 
            // عرضالعملياتToolStripMenuItem
            // 
            this.عرضالعملياتToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_list_25px;
            this.عرضالعملياتToolStripMenuItem.Name = "عرضالعملياتToolStripMenuItem";
            this.عرضالعملياتToolStripMenuItem.Size = new System.Drawing.Size(151, 26);
            this.عرضالعملياتToolStripMenuItem.Text = "عرض العمليات";
            this.عرضالعملياتToolStripMenuItem.Click += new System.EventHandler(this.عرضالعملياتToolStripMenuItem_Click);
            // 
            // تصنيفاتالوكلاءToolStripMenuItem
            // 
            this.تصنيفاتالوكلاءToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_categorize_25px;
            this.تصنيفاتالوكلاءToolStripMenuItem.Name = "تصنيفاتالوكلاءToolStripMenuItem";
            this.تصنيفاتالوكلاءToolStripMenuItem.Size = new System.Drawing.Size(183, 26);
            this.تصنيفاتالوكلاءToolStripMenuItem.Text = "تصنيفات الوكلاء";
            this.تصنيفاتالوكلاءToolStripMenuItem.Click += new System.EventHandler(this.تصنيفاتالوكلاءToolStripMenuItem_Click);
            // 
            // مطابقاتالوكلاءToolStripMenuItem
            // 
            this.مطابقاتالوكلاءToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_control_panel_25px;
            this.مطابقاتالوكلاءToolStripMenuItem.Name = "مطابقاتالوكلاءToolStripMenuItem";
            this.مطابقاتالوكلاءToolStripMenuItem.Size = new System.Drawing.Size(183, 26);
            this.مطابقاتالوكلاءToolStripMenuItem.Text = "مطابقات الوكلاء";
            this.مطابقاتالوكلاءToolStripMenuItem.Click += new System.EventHandler(this.مطابقاتالوكلاءToolStripMenuItem_Click);
            // 
            // الموادToolStripMenuItem
            // 
            this.الموادToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إضافةمادةToolStripMenuItem,
            this.عرضالموادToolStripMenuItem,
            this.تصنيفاتالموادToolStripMenuItem,
            this.الواحداتToolStripMenuItem,
            this.كشفحسابمادةToolStripMenuItem,
            this.تسعيرالموادToolStripMenuItem,
            this.كمياتالموادToolStripMenuItem,
            this.كشفحركةالمادةToolStripMenuItem});
            this.الموادToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_product_25px;
            this.الموادToolStripMenuItem.Name = "الموادToolStripMenuItem";
            this.الموادToolStripMenuItem.Size = new System.Drawing.Size(68, 24);
            this.الموادToolStripMenuItem.Text = "المواد";
            // 
            // إضافةمادةToolStripMenuItem
            // 
            this.إضافةمادةToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_add_shopping_cart_25px;
            this.إضافةمادةToolStripMenuItem.Name = "إضافةمادةToolStripMenuItem";
            this.إضافةمادةToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.إضافةمادةToolStripMenuItem.Text = "إضافة مادة";
            this.إضافةمادةToolStripMenuItem.Click += new System.EventHandler(this.إضافةمادةToolStripMenuItem_Click);
            // 
            // عرضالموادToolStripMenuItem
            // 
            this.عرضالموادToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_sell_stock_25px;
            this.عرضالموادToolStripMenuItem.Name = "عرضالموادToolStripMenuItem";
            this.عرضالموادToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.عرضالموادToolStripMenuItem.Text = "عرض المواد";
            this.عرضالموادToolStripMenuItem.Click += new System.EventHandler(this.عرضالموادToolStripMenuItem_Click);
            // 
            // تصنيفاتالموادToolStripMenuItem
            // 
            this.تصنيفاتالموادToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_descending_sorting_25px;
            this.تصنيفاتالموادToolStripMenuItem.Name = "تصنيفاتالموادToolStripMenuItem";
            this.تصنيفاتالموادToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.تصنيفاتالموادToolStripMenuItem.Text = "تصنيفات المواد";
            this.تصنيفاتالموادToolStripMenuItem.Click += new System.EventHandler(this.تصنيفاتالموادToolStripMenuItem_Click);
            // 
            // الواحداتToolStripMenuItem
            // 
            this.الواحداتToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_unit_25px;
            this.الواحداتToolStripMenuItem.Name = "الواحداتToolStripMenuItem";
            this.الواحداتToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.الواحداتToolStripMenuItem.Text = "الواحدات";
            this.الواحداتToolStripMenuItem.Click += new System.EventHandler(this.الواحداتToolStripMenuItem_Click);
            // 
            // كشفحسابمادةToolStripMenuItem
            // 
            this.كشفحسابمادةToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_control_panel_25px1;
            this.كشفحسابمادةToolStripMenuItem.Name = "كشفحسابمادةToolStripMenuItem";
            this.كشفحسابمادةToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.كشفحسابمادةToolStripMenuItem.Text = "كشف حساب مادة";
            this.كشفحسابمادةToolStripMenuItem.Click += new System.EventHandler(this.كشفحسابمادةToolStripMenuItem_Click);
            // 
            // تسعيرالموادToolStripMenuItem
            // 
            this.تسعيرالموادToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_cash_25px;
            this.تسعيرالموادToolStripMenuItem.Name = "تسعيرالموادToolStripMenuItem";
            this.تسعيرالموادToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.تسعيرالموادToolStripMenuItem.Text = "تسعير المواد";
            this.تسعيرالموادToolStripMenuItem.Click += new System.EventHandler(this.تسعيرالموادToolStripMenuItem_Click);
            // 
            // كمياتالموادToolStripMenuItem
            // 
            this.كمياتالموادToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_shop_25px;
            this.كمياتالموادToolStripMenuItem.Name = "كمياتالموادToolStripMenuItem";
            this.كمياتالموادToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.كمياتالموادToolStripMenuItem.Text = "كميات المواد";
            this.كمياتالموادToolStripMenuItem.Click += new System.EventHandler(this.كمياتالموادToolStripMenuItem_Click);
            // 
            // كشفحركةالمادةToolStripMenuItem
            // 
            this.كشفحركةالمادةToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_active_directory_25px;
            this.كشفحركةالمادةToolStripMenuItem.Name = "كشفحركةالمادةToolStripMenuItem";
            this.كشفحركةالمادةToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.كشفحركةالمادةToolStripMenuItem.Text = "كشف حركة المادة";
            this.كشفحركةالمادةToolStripMenuItem.Click += new System.EventHandler(this.كشفحركةالمادةToolStripMenuItem_Click);
            // 
            // billsbtn
            // 
            this.billsbtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.POSbtn,
            this.buybillbtn,
            this.sellbillbtn,
            this.billmanagementbtn});
            this.billsbtn.Image = global::Alver.Properties.Resources.icons8_bill_25px;
            this.billsbtn.Name = "billsbtn";
            this.billsbtn.Size = new System.Drawing.Size(74, 24);
            this.billsbtn.Text = "الفواتير";
            // 
            // POSbtn
            // 
            this.POSbtn.Image = global::Alver.Properties.Resources.icons8_barcode_reader_25px;
            this.POSbtn.Name = "POSbtn";
            this.POSbtn.Size = new System.Drawing.Size(141, 26);
            this.POSbtn.Text = "نقطة البيع";
            this.POSbtn.Click += new System.EventHandler(this.POSbtn_Click_1);
            // 
            // buybillbtn
            // 
            this.buybillbtn.Image = global::Alver.Properties.Resources.icons8_purchase_order_25px;
            this.buybillbtn.Name = "buybillbtn";
            this.buybillbtn.Size = new System.Drawing.Size(141, 26);
            this.buybillbtn.Text = "فاتورة شراء";
            this.buybillbtn.Click += new System.EventHandler(this.buybillbtn_Click);
            // 
            // sellbillbtn
            // 
            this.sellbillbtn.Image = global::Alver.Properties.Resources.icons8_invoice_25px;
            this.sellbillbtn.Name = "sellbillbtn";
            this.sellbillbtn.Size = new System.Drawing.Size(141, 26);
            this.sellbillbtn.Text = "فاتورة بيع";
            this.sellbillbtn.Click += new System.EventHandler(this.sellbillbtn_Click);
            // 
            // billmanagementbtn
            // 
            this.billmanagementbtn.Image = global::Alver.Properties.Resources.itemsettings;
            this.billmanagementbtn.Name = "billmanagementbtn";
            this.billmanagementbtn.Size = new System.Drawing.Size(141, 26);
            this.billmanagementbtn.Text = "إداراة الفواتير";
            this.billmanagementbtn.Click += new System.EventHandler(this.billmanagementbtn_Click);
            // 
            // الصناديقToolStripMenuItem
            // 
            this.الصناديقToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.سحبوتغذيةالصناديقToolStripMenuItem,
            this.toolStripSeparator5,
            this.كشفحسابتفصيليToolStripMenuItem,
            this.toolStripSeparator6,
            this.floatingfundsbtn});
            this.الصناديقToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_safe_25px;
            this.الصناديقToolStripMenuItem.Name = "الصناديقToolStripMenuItem";
            this.الصناديقToolStripMenuItem.Size = new System.Drawing.Size(84, 24);
            this.الصناديقToolStripMenuItem.Text = "الصناديق";
            // 
            // سحبوتغذيةالصناديقToolStripMenuItem
            // 
            this.سحبوتغذيةالصناديقToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إضافةحركةToolStripMenuItem1,
            this.عرضالحركاتToolStripMenuItem1});
            this.سحبوتغذيةالصناديقToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_withdrawal_25px;
            this.سحبوتغذيةالصناديقToolStripMenuItem.Name = "سحبوتغذيةالصناديقToolStripMenuItem";
            this.سحبوتغذيةالصناديقToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.سحبوتغذيةالصناديقToolStripMenuItem.Text = "سحب وتغذية الصناديق";
            // 
            // إضافةحركةToolStripMenuItem1
            // 
            this.إضافةحركةToolStripMenuItem1.Image = global::Alver.Properties.Resources.icons8_cash_in_hand_25px;
            this.إضافةحركةToolStripMenuItem1.Name = "إضافةحركةToolStripMenuItem1";
            this.إضافةحركةToolStripMenuItem1.Size = new System.Drawing.Size(146, 26);
            this.إضافةحركةToolStripMenuItem1.Text = "إضافة حركة";
            this.إضافةحركةToolStripMenuItem1.Click += new System.EventHandler(this.إضافةحركةToolStripMenuItem1_Click);
            // 
            // عرضالحركاتToolStripMenuItem1
            // 
            this.عرضالحركاتToolStripMenuItem1.Image = global::Alver.Properties.Resources.icons8_list_25px;
            this.عرضالحركاتToolStripMenuItem1.Name = "عرضالحركاتToolStripMenuItem1";
            this.عرضالحركاتToolStripMenuItem1.Size = new System.Drawing.Size(146, 26);
            this.عرضالحركاتToolStripMenuItem1.Text = "عرض الحركات";
            this.عرضالحركاتToolStripMenuItem1.Click += new System.EventHandler(this.عرضالحركاتToolStripMenuItem1_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(187, 6);
            // 
            // كشفحسابتفصيليToolStripMenuItem
            // 
            this.كشفحسابتفصيليToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_control_panel_25px;
            this.كشفحسابتفصيليToolStripMenuItem.Name = "كشفحسابتفصيليToolStripMenuItem";
            this.كشفحسابتفصيليToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.كشفحسابتفصيليToolStripMenuItem.Text = "كشف حساب تفصيلي";
            this.كشفحسابتفصيليToolStripMenuItem.Click += new System.EventHandler(this.كشفحسابتفصيليToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(187, 6);
            // 
            // floatingfundsbtn
            // 
            this.floatingfundsbtn.Image = global::Alver.Properties.Resources.icons8_crowdfunding_25px;
            this.floatingfundsbtn.Name = "floatingfundsbtn";
            this.floatingfundsbtn.Size = new System.Drawing.Size(190, 26);
            this.floatingfundsbtn.Text = "حركة الصناديق";
            this.floatingfundsbtn.Click += new System.EventHandler(this.floatingfundsbtn_Click);
            // 
            // الصرافةToolStripMenuItem
            // 
            this.الصرافةToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إضافةعملياتصرافةToolStripMenuItem,
            this.نشرةالأسعارToolStripMenuItem});
            this.الصرافةToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_currency_exchange_25px;
            this.الصرافةToolStripMenuItem.Name = "الصرافةToolStripMenuItem";
            this.الصرافةToolStripMenuItem.Size = new System.Drawing.Size(76, 24);
            this.الصرافةToolStripMenuItem.Text = "الصرافة";
            // 
            // إضافةعملياتصرافةToolStripMenuItem
            // 
            this.إضافةعملياتصرافةToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_exchange_25px;
            this.إضافةعملياتصرافةToolStripMenuItem.Name = "إضافةعملياتصرافةToolStripMenuItem";
            this.إضافةعملياتصرافةToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.إضافةعملياتصرافةToolStripMenuItem.Text = "سجل عمليات الصرافة";
            this.إضافةعملياتصرافةToolStripMenuItem.Click += new System.EventHandler(this.إضافةعملياتصرافةToolStripMenuItem_Click);
            // 
            // نشرةالأسعارToolStripMenuItem
            // 
            this.نشرةالأسعارToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_combo_chart_25px;
            this.نشرةالأسعارToolStripMenuItem.Name = "نشرةالأسعارToolStripMenuItem";
            this.نشرةالأسعارToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.نشرةالأسعارToolStripMenuItem.Text = "نشرة الأسعار";
            this.نشرةالأسعارToolStripMenuItem.Click += new System.EventHandler(this.نشرةالأسعارToolStripMenuItem_Click);
            // 
            // المصاريفToolStripMenuItem
            // 
            this.المصاريفToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addExpensebtn,
            this.viewExpensesbtn,
            this.toolStripSeparator1,
            this.expensesCategoriesbtn});
            this.المصاريفToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_no_cash_25px;
            this.المصاريفToolStripMenuItem.Name = "المصاريفToolStripMenuItem";
            this.المصاريفToolStripMenuItem.Size = new System.Drawing.Size(90, 24);
            this.المصاريفToolStripMenuItem.Text = "المصاريف";
            // 
            // addExpensebtn
            // 
            this.addExpensebtn.Image = global::Alver.Properties.Resources.icons8_donate_25px;
            this.addExpensebtn.Name = "addExpensebtn";
            this.addExpensebtn.Size = new System.Drawing.Size(176, 26);
            this.addExpensebtn.Text = "إضافة مصروف";
            this.addExpensebtn.Click += new System.EventHandler(this.addExpensebtn_Click);
            // 
            // viewExpensesbtn
            // 
            this.viewExpensesbtn.Image = global::Alver.Properties.Resources.icons8_list_25px;
            this.viewExpensesbtn.Name = "viewExpensesbtn";
            this.viewExpensesbtn.Size = new System.Drawing.Size(176, 26);
            this.viewExpensesbtn.Text = "عرض المصاريف";
            this.viewExpensesbtn.Click += new System.EventHandler(this.viewExpensesbtn_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(173, 6);
            // 
            // expensesCategoriesbtn
            // 
            this.expensesCategoriesbtn.Image = global::Alver.Properties.Resources.icons8_descending_sorting_25px;
            this.expensesCategoriesbtn.Name = "expensesCategoriesbtn";
            this.expensesCategoriesbtn.Size = new System.Drawing.Size(176, 26);
            this.expensesCategoriesbtn.Text = "تصنيفات المصاريف";
            this.expensesCategoriesbtn.Click += new System.EventHandler(this.expensesCategoriesbtn_Click);
            // 
            // المدفوعاتوالمقبوضاتToolStripMenuItem
            // 
            this.المدفوعاتوالمقبوضاتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.الديونToolStripMenuItem,
            this.depositesbtn});
            this.المدفوعاتوالمقبوضاتToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_paper_money_25px;
            this.المدفوعاتوالمقبوضاتToolStripMenuItem.Name = "المدفوعاتوالمقبوضاتToolStripMenuItem";
            this.المدفوعاتوالمقبوضاتToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.المدفوعاتوالمقبوضاتToolStripMenuItem.Text = "المدفوعات والمقبوضات";
            // 
            // الديونToolStripMenuItem
            // 
            this.الديونToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addLoanbtn,
            this.viewLoansbtn});
            this.الديونToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_request_money_25px;
            this.الديونToolStripMenuItem.Name = "الديونToolStripMenuItem";
            this.الديونToolStripMenuItem.Size = new System.Drawing.Size(116, 26);
            this.الديونToolStripMenuItem.Text = "الديون";
            // 
            // addLoanbtn
            // 
            this.addLoanbtn.Image = global::Alver.Properties.Resources.icons8_debt_25px_1;
            this.addLoanbtn.Name = "addLoanbtn";
            this.addLoanbtn.Size = new System.Drawing.Size(129, 26);
            this.addLoanbtn.Text = "إضافة دين";
            this.addLoanbtn.Click += new System.EventHandler(this.addLoanbtn_Click);
            // 
            // viewLoansbtn
            // 
            this.viewLoansbtn.Image = global::Alver.Properties.Resources.icons8_list_25px;
            this.viewLoansbtn.Name = "viewLoansbtn";
            this.viewLoansbtn.Size = new System.Drawing.Size(129, 26);
            this.viewLoansbtn.Text = "الديون";
            this.viewLoansbtn.Click += new System.EventHandler(this.viewLoansbtn_Click);
            // 
            // depositesbtn
            // 
            this.depositesbtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addDepositebtn,
            this.viewDepositesbtn});
            this.depositesbtn.Image = global::Alver.Properties.Resources.icons8_initiate_money_transfer_25px;
            this.depositesbtn.Name = "depositesbtn";
            this.depositesbtn.Size = new System.Drawing.Size(116, 26);
            this.depositesbtn.Text = "الأمانات";
            // 
            // addDepositebtn
            // 
            this.addDepositebtn.Image = global::Alver.Properties.Resources.icons8_withdrawal_25px;
            this.addDepositebtn.Name = "addDepositebtn";
            this.addDepositebtn.Size = new System.Drawing.Size(134, 26);
            this.addDepositebtn.Text = "إضافة أمانة";
            this.addDepositebtn.Click += new System.EventHandler(this.addDepositebtn_Click);
            // 
            // viewDepositesbtn
            // 
            this.viewDepositesbtn.Image = global::Alver.Properties.Resources.icons8_list_25px;
            this.viewDepositesbtn.Name = "viewDepositesbtn";
            this.viewDepositesbtn.Size = new System.Drawing.Size(134, 26);
            this.viewDepositesbtn.Text = "الأمانات";
            this.viewDepositesbtn.Click += new System.EventHandler(this.viewDepositesbtn_Click);
            // 
            // المستخدمونToolStripMenuItem
            // 
            this.المستخدمونToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إدارةالمستخدمينToolStripMenuItem});
            this.المستخدمونToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_guardian_25px;
            this.المستخدمونToolStripMenuItem.Name = "المستخدمونToolStripMenuItem";
            this.المستخدمونToolStripMenuItem.Size = new System.Drawing.Size(101, 24);
            this.المستخدمونToolStripMenuItem.Text = "المستخدمون";
            // 
            // إدارةالمستخدمينToolStripMenuItem
            // 
            this.إدارةالمستخدمينToolStripMenuItem.Image = global::Alver.Properties.Resources.icons8_admin_settings_male_25px;
            this.إدارةالمستخدمينToolStripMenuItem.Name = "إدارةالمستخدمينToolStripMenuItem";
            this.إدارةالمستخدمينToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.إدارةالمستخدمينToolStripMenuItem.Text = "إدارة المستخدمين";
            this.إدارةالمستخدمينToolStripMenuItem.Click += new System.EventHandler(this.إدارةالمستخدمينToolStripMenuItem_Click);
            // 
            // BodysplitContainer
            // 
            this.BodysplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BodysplitContainer.Location = new System.Drawing.Point(0, 0);
            this.BodysplitContainer.Name = "BodysplitContainer";
            // 
            // BodysplitContainer.Panel1
            // 
            this.BodysplitContainer.Panel1.BackColor = System.Drawing.SystemColors.Control;
            this.BodysplitContainer.Panel1.BackgroundImage = global::Alver.Properties.Resources.BG__3_;
            this.BodysplitContainer.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BodysplitContainer.Panel1.Controls.Add(this.button2);
            this.BodysplitContainer.Panel1.Controls.Add(this.button1);
            this.BodysplitContainer.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // BodysplitContainer.Panel2
            // 
            this.BodysplitContainer.Panel2.BackColor = System.Drawing.SystemColors.Control;
            this.BodysplitContainer.Panel2.BackgroundImage = global::Alver.Properties.Resources.abstract_blue_background_wave_vector_1407_88;
            this.BodysplitContainer.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BodysplitContainer.Panel2.Controls.Add(this.clocklbl);
            this.BodysplitContainer.Panel2.Controls.Add(this.phonelbl);
            this.BodysplitContainer.Panel2.Controls.Add(this.addresslbl);
            this.BodysplitContainer.Panel2.Controls.Add(this.companytitlelbl);
            this.BodysplitContainer.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.BodysplitContainer.Size = new System.Drawing.Size(882, 400);
            this.BodysplitContainer.SplitterDistance = 736;
            this.BodysplitContainer.SplitterWidth = 20;
            this.BodysplitContainer.TabIndex = 0;
            this.BodysplitContainer.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.BodysplitContainer_SplitterMoved);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.button2.Image = global::Alver.Properties.Resources.icons8_barcode_reader_25px;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.Location = new System.Drawing.Point(3, 59);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 50);
            this.button2.TabIndex = 1;
            this.button2.Text = "نقطة البيع";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button2.UseCompatibleTextRendering = true;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.button1.Image = global::Alver.Properties.Resources.icons8_barcode_reader_25px;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.Location = new System.Drawing.Point(3, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 50);
            this.button1.TabIndex = 0;
            this.button1.Text = "نقطة البيع";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseCompatibleTextRendering = true;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.POSbtn_Click_1);
            // 
            // clocklbl
            // 
            this.clocklbl.BackColor = System.Drawing.Color.Transparent;
            this.clocklbl.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.clocklbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clocklbl.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.clocklbl.ForeColor = System.Drawing.Color.OrangeRed;
            this.clocklbl.Location = new System.Drawing.Point(0, 355);
            this.clocklbl.Name = "clocklbl";
            this.clocklbl.Size = new System.Drawing.Size(126, 45);
            this.clocklbl.TabIndex = 3;
            this.clocklbl.Text = "0";
            this.clocklbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.clocklbl.UseCompatibleTextRendering = true;
            // 
            // phonelbl
            // 
            this.phonelbl.BackColor = System.Drawing.Color.Transparent;
            this.phonelbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.phonelbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.phonelbl.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.phonelbl.Location = new System.Drawing.Point(0, 90);
            this.phonelbl.Name = "phonelbl";
            this.phonelbl.Size = new System.Drawing.Size(126, 45);
            this.phonelbl.TabIndex = 2;
            this.phonelbl.Text = "0";
            this.phonelbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.phonelbl.UseCompatibleTextRendering = true;
            // 
            // addresslbl
            // 
            this.addresslbl.BackColor = System.Drawing.Color.Transparent;
            this.addresslbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.addresslbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addresslbl.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.addresslbl.Location = new System.Drawing.Point(0, 45);
            this.addresslbl.Name = "addresslbl";
            this.addresslbl.Size = new System.Drawing.Size(126, 45);
            this.addresslbl.TabIndex = 1;
            this.addresslbl.Text = "0";
            this.addresslbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.addresslbl.UseCompatibleTextRendering = true;
            // 
            // companytitlelbl
            // 
            this.companytitlelbl.BackColor = System.Drawing.Color.Transparent;
            this.companytitlelbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.companytitlelbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.companytitlelbl.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.companytitlelbl.Location = new System.Drawing.Point(0, 0);
            this.companytitlelbl.Name = "companytitlelbl";
            this.companytitlelbl.Size = new System.Drawing.Size(126, 45);
            this.companytitlelbl.TabIndex = 0;
            this.companytitlelbl.Text = "0";
            this.companytitlelbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.companytitlelbl.UseCompatibleTextRendering = true;
            // 
            // mainstatusstrip
            // 
            this.mainstatusstrip.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mainstatusstrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mainstatusstrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.usernameLabel,
            this.toolStripStatusLabel3,
            this.databasenamelbl,
            this.runtimeslbl});
            this.mainstatusstrip.Location = new System.Drawing.Point(0, 449);
            this.mainstatusstrip.Name = "mainstatusstrip";
            this.mainstatusstrip.Size = new System.Drawing.Size(882, 22);
            this.mainstatusstrip.TabIndex = 1;
            this.mainstatusstrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(92, 17);
            this.toolStripStatusLabel1.Text = "المستخدم الحالي:";
            // 
            // usernameLabel
            // 
            this.usernameLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.usernameLabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(12, 17);
            this.usernameLabel.Text = "-";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolStripStatusLabel3.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(77, 17);
            this.toolStripStatusLabel3.Text = "قاعدة البيانات:";
            // 
            // databasenamelbl
            // 
            this.databasenamelbl.ForeColor = System.Drawing.Color.White;
            this.databasenamelbl.Name = "databasenamelbl";
            this.databasenamelbl.Size = new System.Drawing.Size(19, 17);
            this.databasenamelbl.Text = "00";
            // 
            // runtimeslbl
            // 
            this.runtimeslbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.runtimeslbl.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.runtimeslbl.Name = "runtimeslbl";
            this.runtimeslbl.Size = new System.Drawing.Size(21, 17);
            this.runtimeslbl.Text = "00";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(882, 471);
            this.Controls.Add(this.HeadersplitContainer);
            this.Controls.Add(this.mainstatusstrip);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mainmenustrip;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alver";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.HeadersplitContainer.Panel1.ResumeLayout(false);
            this.HeadersplitContainer.Panel1.PerformLayout();
            this.HeadersplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.HeadersplitContainer)).EndInit();
            this.HeadersplitContainer.ResumeLayout(false);
            this.mainmenustrip.ResumeLayout(false);
            this.mainmenustrip.PerformLayout();
            this.BodysplitContainer.Panel1.ResumeLayout(false);
            this.BodysplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BodysplitContainer)).EndInit();
            this.BodysplitContainer.ResumeLayout(false);
            this.mainstatusstrip.ResumeLayout(false);
            this.mainstatusstrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer HeadersplitContainer;
        private System.Windows.Forms.SplitContainer BodysplitContainer;
        private System.Windows.Forms.StatusStrip mainstatusstrip;
        private System.Windows.Forms.MenuStrip mainmenustrip;
        private System.Windows.Forms.ToolStripMenuItem ملفToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutbtn;
        private System.Windows.Forms.ToolStripMenuItem إغلاقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المستخدمونToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إدارةالمستخدمينToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المصاريفToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addExpensebtn;
        private System.Windows.Forms.ToolStripMenuItem viewExpensesbtn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem expensesCategoriesbtn;
        private System.Windows.Forms.ToolStripMenuItem المدفوعاتوالمقبوضاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الديونToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addLoanbtn;
        private System.Windows.Forms.ToolStripMenuItem viewLoansbtn;
        private System.Windows.Forms.ToolStripMenuItem depositesbtn;
        private System.Windows.Forms.ToolStripMenuItem addDepositebtn;
        private System.Windows.Forms.ToolStripMenuItem viewDepositesbtn;
        private System.Windows.Forms.ToolStripMenuItem addclientbtn;
        private System.Windows.Forms.ToolStripMenuItem clientsbtn;
        private System.Windows.Forms.ToolStripMenuItem clientoverviewbtn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem دفعاتالوكلاءToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إضافةدفعةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرضالدفعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem withdrawbtn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem إضافةحركةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرضالحركاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قصوتحويلالرصيدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutbtn;
        private System.Windows.Forms.ToolStripMenuItem transferbtn;
        private System.Windows.Forms.ToolStripMenuItem عرضالعملياتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الصناديقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem سحبوتغذيةالصناديقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إضافةحركةToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem عرضالحركاتToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem كشفحسابتفصيليToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem floatingfundsbtn;
        private System.Windows.Forms.ToolStripMenuItem billsbtn;
        private System.Windows.Forms.ToolStripMenuItem buybillbtn;
        private System.Windows.Forms.ToolStripMenuItem sellbillbtn;
        private System.Windows.Forms.ToolStripMenuItem الموادToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إضافةمادةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرضالموادToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تصنيفاتالموادToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الواحداتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الصرافةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إضافةعملياتصرافةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem نشرةالأسعارToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem كشفحسابمادةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem أخذنسخةاحتياطيةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem استرجاعنسخةاحتياطيةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تصنيفاتالوكلاءToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تسعيرالموادToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مطابقاتالوكلاءToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem كمياتالموادToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إعدادتالبرنامجToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مساعدإعدادقاعدةالبياناتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem billmanagementbtn;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel usernameLabel;
        private System.Windows.Forms.ToolStripStatusLabel runtimeslbl;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel databasenamelbl;
        private System.Windows.Forms.ToolStripMenuItem كشفحركةالمادةToolStripMenuItem;
        private System.Windows.Forms.Label companytitlelbl;
        private System.Windows.Forms.Label addresslbl;
        private System.Windows.Forms.Label phonelbl;
        private System.Windows.Forms.Label clocklbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem POSbtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}