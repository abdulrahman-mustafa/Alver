﻿namespace Alver.Misc
{
    public class datatable
    {
    }
}